from fastapi import FastAPI

app = FastAPI(
    title="SETU-NER API",
    description="AI Route Resilience Platform for North Eastern Region",
    version="0.1.0",
)


@app.get("/")
def root():
    return {
        "success": True,
        "project": "SETU-NER",
        "message": "SETU-NER backend is running",
    }


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "setu-ner-api",
    }
