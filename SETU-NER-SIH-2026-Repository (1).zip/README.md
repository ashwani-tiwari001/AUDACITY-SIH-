# SETU-NER — Know the Road Before You Take It

## SIH 2026 Project Repository

### Project Information

- **Project Title:** SETU-NER — AI Route Resilience Platform
- **Problem Statement ID:** SIH26002
- **Problem Statement Title:** AI-Based Smart Logistics & Accessibility Intelligence Platform for NER
- **Theme:** Smart Automation
- **Category:** Software
- **Team ID:** [Your Team ID]
- **Team Name:** Audacity

## Problem Statement

Landslides, floods and poor connectivity can strand medicines, food and fuel in remote North Eastern Region (NER) districts. A major challenge is the lack of live visibility into road and route conditions.

## Proposed Solution

SETU-NER is an AI-based route resilience platform designed to combine satellite/weather information, IoT bridge sensors, GPS fleet data and offline crowd reports. The platform scores road segments as **Safe**, **At-Risk** or **Blocked** and recommends safer routes.

The system also proposes an SMS/IVR fallback so drivers and field staff in zero-network zones can submit information to the same intelligence system used by the web dashboard.

## Key Features

- Road risk assessment
- Safe / At-Risk / Blocked classification
- AI-assisted route recommendation
- Weather and disruption information integration
- GPS fleet data integration
- IoT sensor data integration
- Offline crowd reporting
- SMS/IVR fallback concept
- Route disruption forecasting
- Map-based route visualization
- Data-driven planning support

> Features marked as concepts should be implemented and validated before being described as production-ready capabilities.

## Technical Approach

### AI/ML
- Random Forest
- XGBoost
- LSTM for disruption forecasting

### Route Optimization
- A*
- Dijkstra

### Data and Platform
- ISRO Bhuvan / relevant satellite data
- IMD / relevant weather data
- MoRTH data
- IoT telemetry
- GPS telemetry
- React / Flutter
- Node.js / FastAPI
- PostGIS
- Offline-first PWA
- SMS/IVR gateway

The final implementation should list only technologies and integrations actually used in the submitted build.

## High-Level Architecture

```text
User
 |
 v
Web / Mobile Dashboard
 |
 v
Backend API
 |
 +----------+----------+----------+
 |          |          |          |
 v          v          v          v
Database   ML Model   GPS/IoT   External Data
 |          |          |          |
 +----------+----------+----------+
              |
              v
        Road Risk Score
              |
              v
       Route Optimization
              |
              v
        Safe Route Suggestion
```

See [`docs/architecture.md`](docs/architecture.md) for the detailed architecture.

## Repository Structure

```text
SETU-NER/
├── README.md
├── SUBMISSION_GUIDE.md
├── submission/
│   ├── PRESENTATION.md
│   └── DEMO.md
├── src/
│   └── main.py
├── docs/
│   └── architecture.md
├── assets/
│   └── screenshots/
│       └── README.md
├── requirements.txt
├── .gitignore
└── LICENSE
```

## Installation

Clone the repository and install the Python dependencies:

```bash
git clone <YOUR_REPOSITORY_URL>
cd SETU-NER
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
uvicorn src.main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

The included `src/main.py` is a minimal API starter and should be replaced/extended with the actual project implementation.

## API Health Check

```text
GET /
```

Returns a basic status response.

## Configuration and Secrets

Do not commit:

- Passwords
- API keys
- Access tokens
- `.env` files containing secrets
- Private credentials
- Confidential government or partner data

Use environment variables for secrets.

## Future Scope

- Expand coverage across additional NER corridors
- Integrate additional real-time data sources
- Improve prediction accuracy with larger datasets
- Add more IoT sensor types
- Improve offline functionality
- Expand SMS/IVR workflows
- Integrate operational workflows for relevant agencies
- Scale district-by-district
- Add richer mobile support

## References

The project presentation identifies the following references:

1. SIH26002 — Official Problem Statement, Ministry of Development of North Eastern Region (MDoNER), SIH 2026 portal.
2. India Landslide Susceptibility Map, IIT Delhi, Civil Engineering & Yardi School of AI, 2024.
3. Agrawal, N. & Dixit, J. (2021), *Landslide Susceptibility for Meghalaya (NER) using Bivariate & Multi-Criteria Decision Models*, Shiv Nadar University.
4. Ministry of Road Transport & Highways, Lok Sabha Unstarred Question No. 4583, 27 March 2025.
5. Border Roads Organisation — performance overview.
6. Morung Express (2023) — NH-6 Sonapur landslide case study.

## Team

**Team Name:** Audacity

**Team ID:** [Your Team ID]
