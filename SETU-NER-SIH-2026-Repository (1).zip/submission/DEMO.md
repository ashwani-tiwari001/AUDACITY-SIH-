# SETU-NER Demo

## Demo Video

**Demo link:** [ADD YOUTUBE OR GOOGLE DRIVE LINK]

## Demo Flow

Recommended demonstration sequence:

1. Open the SETU-NER dashboard.
2. Show the selected route/corridor.
3. Show road risk status.
4. Show available weather/environmental information.
5. Show how risk information affects route selection.
6. Demonstrate the recommended safer route.
7. Demonstrate reporting/input functionality if implemented.
8. Show offline/SMS/IVR functionality if implemented.
9. Explain the architecture briefly.
