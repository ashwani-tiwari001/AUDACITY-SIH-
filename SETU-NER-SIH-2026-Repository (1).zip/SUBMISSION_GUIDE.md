# SIH 2026 Submission Guide — SETU-NER

## Purpose

This repository is organized to provide SIH reviewers with the project overview, source code, technical documentation, presentation, demo information and screenshots.

## Before Submission Checklist

### Project information
- [ ] Project title is correct
- [ ] PS ID is correct
- [ ] PS title is correct
- [ ] Team ID is filled in
- [ ] Team name matches the SIH portal

### Source code
- [ ] Final source code is pushed
- [ ] The project builds/runs successfully
- [ ] Installation instructions are correct
- [ ] No passwords or API keys are committed

### Documentation
- [ ] README is complete
- [ ] Architecture document is updated
- [ ] Technology stack matches the actual implementation
- [ ] Future scope is realistic

### Presentation
- [ ] Final SIH presentation is added or linked
- [ ] The presentation link is accessible to reviewers

### Demo
- [ ] Demo video is uploaded if available
- [ ] Demo link is added to `submission/DEMO.md`
- [ ] Demo link is accessible without requesting private permission

### Screenshots
- [ ] Important application screens are added to `assets/screenshots/`
- [ ] Screenshot names are descriptive
- [ ] Screenshots do not expose secrets or private information

## Important

Do not claim an integration, ML model, live data source or feature as completed unless it is actually present and working in the submitted project.

Replace all placeholders such as `[Your Team ID]` before final submission.
