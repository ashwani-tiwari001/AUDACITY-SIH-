# SETU-NER Technical Architecture

## 1. Overview

SETU-NER is designed as an AI-based route resilience platform for the North Eastern Region. It combines multiple sources of operational and environmental information to estimate road risk and support safer route planning.

## 2. System Flow

```text
                    +----------------------+
                    |        User          |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | Web / Mobile Client  |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |     Backend API      |
                    +----------+-----------+
                               |
             +-----------------+------------------+
             |                 |                  |
             v                 v                  v
      +-------------+   +-------------+   +-------------+
      |   Database  |   |  ML Engine  |   | Data Inputs |
      +-------------+   +-------------+   +-------------+
             |                 |                  |
             |          +------+-------+          |
             |          |              |          |
             |          v              v          |
             |     Risk Classifier   Forecasting  |
             |          |              |          |
             +----------+------+-------+----------+
                            |
                            v
                   +-------------------+
                   | Road Risk Score   |
                   +---------+---------+
                             |
                             v
                   +-------------------+
                   | Route Optimization|
                   | A* / Dijkstra     |
                   +---------+---------+
                             |
                             v
                   +-------------------+
                   | Safer Route       |
                   | Recommendation    |
                   +-------------------+
```

## 3. Data Sources

The proposed platform can use:

- Satellite/geospatial information
- Weather information
- IoT bridge/road sensor data
- GPS fleet telemetry
- Offline crowd reports

The final implementation should document the exact data sources actually connected to the system.

## 4. Risk Classification

The proposed road-risk output has three primary states:

```text
SAFE
AT-RISK
BLOCKED
```

A risk classifier can use environmental, infrastructure and telemetry features to estimate the state of a road segment.

## 5. Machine Learning

The project proposal identifies:

- Random Forest
- XGBoost
- LSTM disruption forecasting

Random Forest and XGBoost can be used for risk classification, while LSTM can be used for time-dependent disruption forecasting.

The final repository should include the actual trained model, training code, model version and evaluation results if these are implemented.

## 6. Route Optimization

The platform proposes A* and Dijkstra algorithms for route optimization.

A route can be represented as a graph:

```text
Road network
    |
    v
Nodes = locations/intersections
Edges = road segments
Edge weight = travel/risk cost
    |
    v
Shortest / safest path
```

The final implementation should clearly explain the cost function used for safety-aware routing.

## 7. Offline and Low-Connectivity Operation

A major proposed innovation is an SMS/IVR fallback. Drivers and field staff in areas with poor or zero network connectivity can submit reports that feed the same intelligence workflow.

The exact SMS/IVR provider and deployment mechanism should be documented once implemented.

## 8. Database

The proposal identifies PostGIS for geospatial data.

Potential data entities include:

- Road segments
- Locations
- Risk observations
- Weather observations
- GPS positions
- IoT readings
- Reports
- Route requests
- Predictions

Only implemented entities should be included in the final database schema.

## 9. Security

Secrets must be supplied through environment variables or a secure secret manager.

Never store API keys, access tokens or passwords in source control.

## 10. Deployment

The proposal describes cloud-based, scalable deployment. The actual submitted deployment architecture should be documented here after implementation.
