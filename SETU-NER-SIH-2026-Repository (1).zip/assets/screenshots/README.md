# SETU-NER Screenshots

Place important screenshots and prototype photos in this directory.

## Recommended Screenshots

1. `01-dashboard.png` — Main dashboard
2. `02-route-map.png` — Route/map screen
3. `03-risk-analysis.png` — Road risk analysis
4. `04-route-recommendation.png` — Recommended safer route
5. `05-data-sources.png` — Data/telemetry view
6. `06-reporting.png` — User/field reporting
7. `07-mobile.png` — Mobile/responsive interface
8. `08-admin.png` — Admin/operations dashboard

Use actual screenshots from the final project.

Do not upload screenshots containing:
- API keys
- Passwords
- Access tokens
- Personal/private information
- Confidential credentials
